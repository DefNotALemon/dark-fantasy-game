# Build Roadmap — The Withering

Build a *playable game* first, then the living world, then progression, then the
final art + customization pass. Each step should leave the game runnable.

Status keys: [x] done · [~] in progress · [ ] not started

## Step 1 — First-person movement [x]
- [x] FP camera + mouse look, WASD, sprint, jump
- [x] Stamina pool + regen

## Step 2 — Combat core [~]
- [x] Left-click attack loop (3-hit, finisher bonus)
- [x] Right-click block (light) / dodge (heavy)
- [x] Ctrl dash (light build)
- [x] Guard-break: strong attacks smash through a raised block (2s disable + knockback)
- [~] Hit feedback: camera shake in (guard break / heavy hits); hitstop + sound hooks still to do
- [~] Stamina-break on guard still to do; parry window DONE (block within 0.18s of
      impact = no damage/stamina, attacker staggers open, beats guard-breakers)

## Step 3 — First enemy [x]
- [x] Chase AI + melee attack
- [x] Fixed stat sheet (health/damage/speed)
- [x] Wither-to-dust death
- [x] Telegraphed attacks the player can block/dodge (every mob has a glowing windup)
- [x] Multiple enemy archetypes (skeleton, goblin, kobold — plus the boar)
- [x] Two specials per humanoid (smash/sweep, pounce/flurry, lunge/tail-spin)
- [x] Procedural attack animations (arm swings, crouches, spins; melee lands mid-swing)
- [x] Realistic 3-phase cuts (chamber → whip → follow-through) on the player's
      combo + draw slash and all sword mobs; damage lands at the visual impact.
      Per-mob throw power (boar shove 5 → ogre hurl 8.5); blocking = never thrown

## Step 4 — Weapons [~]
- [~] One weapon per type/weight (sword, axe, hammer, knife, bow, etc.) —
      BOW DONE: 1/2 weapon select, hold-to-draw/release-to-loose, arrow
      projectiles with drop, terrain-stuck arrows retrievable, ammo in inventory
- [ ] Base attack loop ("style") per weapon type/weight
- [ ] Menu to equip a style; equipped style drives the left-click loop

## Step 5 — Sword depth [~]
- [ ] Style points earned by use → upgrade styles
- [ ] Per-sword evolution bar (levels the individual weapon)
- [ ] Durability (slow drain, maintenance loop)
- [~] Material → element effects — FIRST PASS DONE (see docs/MATERIALS.md):
      all 10 materials in Materials.gd, matchup × element damage vs enemy
      family tags, aura glow on elemental blades, main-hand slot + click-to-
      wield, Armory dev menu on I, rare tier-weighted v1-slice mob drops
      (iron/steel/silver/meteoric). Element scaling awaits the evolution bar.
      SOURCING NOW LIVE: pickaxe (weapon 3) + mineable ore veins in the caves
      (silver seams anywhere, meteoric guards the deepest room); first ore of
      a new metal forges its sword on the spot, spares stack for smithing later
- [ ] Rarer swords carry unique styles; upgrading the sword adds new swings

## Step 6 — NPCs & passive mobs [~]
- [ ] A couple of NPC types
- [~] Passive wildlife — HORSES DONE (wild + saddled): wild herds graze far out
      and bolt on approach, never rideable; saddled horses near spawn are
      mountable (F) — camera-steered reins, Shift gallop, Space jump, sword-only
      saddle sweeps (left/right by where you look, alternating ahead).
      Hurt ANY horse once and it retaliates: wheels and KICKS you into a
      knockdown (fall + get-up, fully vulnerable, no i-frames — enemies keep
      swinging) and that horse never carries you again. Your own swings can
      never hit the horse you're riding; a horse dying under you still bucks
      you into the same knockdown. More wildlife later

## Step 7 — Nature & buildings [~]
- [x] THIRD PERSON (V) + CROUCH (C): over-shoulder camera with animated
      glide between modes (short press FP->TP right / swap shoulder in TP /
      1.5 s hold back to FP), wall pull-in, persisted last setting; crouch =
      slow low hunter's walk that makes tall grass TRUE cover (×0.35 wake radius)
- [~] Grass — FIRST PASS LIVE ("Valheim architecture, TotK priorities"):
      chunked MultiMesh faceted tufts sampled off the voxel surface, gust
      waves + per-blade sway + bend-away-from-player shader, distance fade,
      wither ring at cave mouths, rebuilds where you dig. TALL HIDING GRASS:
      dense chest-high patches; standing in them (not sprinting) shrinks calm
      mobs' aggro radius to 35% + "~ hidden ~" HUD. Trees still placeholder
- [ ] Real trees (Blender pipeline, docs/TREES_PLAN.md)
- [ ] Reusable building set (castle → townhouse, ~5 reused)

## Step 8 — World & survival basics [ ]
- [ ] A real explorable world chunk (plains/forest/mountain test region)
- [ ] Basic survival (health/healing; more later)

## Step 9 — Living world ("more than a game") [~]
- [~] Procedural caves + dungeons — caves v1 DONE (seeded chamber networks, round
      natural swept tunnels that flare into domed caverns, crystal lighting, cave
      dwellers); dungeons next
- [~] **CAVES 2.0 — full redo, organic noise caves, realistic high-poly** (see
      docs/CAVES_PLAN.md — user brief: DROP the room system): CORE BUILT
      2026-07-14 — CaveField.gd voxel density grid (0.8 m voxels; worm tunnels
      that swell/pinch on their own, cheese caverns, fitable cracks, domain
      warp, surface roof guard, mouth-ramp entrance, sealed rim/bottom) +
      CaveMesher.gd chunked surface-nets skin (flat-shaded, jittered, strata
      vertex colors, grass top skin, trimesh collision) + CaveRegion.gd
      orchestrator (threaded build, BFS reachability placing crystals /
      silver veins / deepest-point meteoric / depth-tiered packs + champion).
      **MINING DIGS NOW**: pickaxe bites carve the field and remesh (slow
      honest shafts up to the surface work); every bite drops falling
      RockDebris.gd rocks, ceiling bites shake loose a big slab (10 dmg
      under it). Chunk/carve/winding logic sim-verified. REMAINING: in-game
      walkthrough + noise tuning, dressing pass (stalactites, pools,
      glowworms, breakdown), cavity tags for titles, squeeze camera-tuck,
      sealed-pocket secrets, perf pass. Old Cave.gd retired (kept on disk).
      Also the foundation for shifting caves below
- [~] Shifting caves — FIRST PASS LIVE via SLEEP: a bedroll at spawn (F to
      sleep until dawn, refused while anything's aggro'd or a build is mid-
      flight); sleeping reseeds every carver and re-carves the whole
      underground on worker threads, sweeps and respawns all deep content
      (mobs/veins/crystals), quake + "The World Has Shifted". PERMANENCE
      BUBBLES (24 m) around every mouth: entrance throats never move, player
      digs inside them survive, and a NO-SPAWN BARRIER keeps content out of
      them. The underground also fully generates at LOAD-IN now (threaded,
      non-blocking) instead of waiting for an approach. Sleep now RE-AUTHORS
      the whole cathedral network (fresh caverns/tunnels/columns each shift).
      Still to do: timed shifts (every 1-2 game days without sleep), stronger
      shake inside, stability bubble mid-shift, entrance collapse cinematic
- [ ] Camps that grow → raid villages/cities
- [x] CAVE-INTERIOR SEALING: the reachability walk can no longer hop rock
      walls into sealed pockets (midpoint check — content only spawns in air
      that truly connects to a mouth), pack members are validated against
      solid rock (fold to pocket center), and a rescue pulls the player home
      if their head spends a full second inside solid ("The earth spat you out")
- [x] PRONE STANCE: C cycles stand/crouch/prone — crawl speed, eye at 0.45
      with chin-forward framing, slow body-weight ease + settling roll (the
      going-prone animation), deepest grass stealth tier (×0.22); plus an
      out-of-bounds rescue teleport if you're ever stuck past the border
- [x] SEALED MAP EDGE (invisible): four unseen 120 m collision walls just
      inside the mesh boundary + the mantle refuses out-of-bounds landings —
      you cannot climb, fall, or be thrown out of the map (no visible wall)
- [x] ZONED UNDERGROUND: a district noise replaces the vastness chaos — the
      caves now have deliberate anatomy: WARRENS (tight round walkable
      tunnels, home of the cracks), GALLERIES (wide flat-lidded corridors),
      HALLS (open caverns); borders blend, districts reshuffle on sleep
      (SUPERSEDED 2026-07-29 by the Cathedral — kept for history)
- [x] THE CATHEDRAL UNDERGROUND (2026-07-29 — noise carvers + districts
      retired): ~13 AUTHORED ellipsoid caverns in three kinds (grand columned
      NAVES 13-19 m / mid HALLS / deep CRYPTS below −23) joined into one
      looping network by a Prim-MST of slope-capped walkable capsule tunnels
      + 2 loop links; every cavern floored with flat 2D-noise SEDIMENT
      terrain (fightable ground, nave core spread ~0.85 m); tapered rock
      columns; worm-noise wobble so nothing reads authored; per-shape AABB
      early-outs; entrance chains auto-link into the network (runtime
      add_mouth included); sleep re-authors everything. PIXEL ROCK RESTYLE
      on both meshers: smooth edge-interpolated geometry (vertex jitter
      retired), flat facets, colors quantized to ~1.1 m TEXELS + per-cell
      value roll — "less real", pixel art draped over stone. Verified by
      tools/cathedral_live_test.gd (12 checks) + smoke/save/lab regressions
- [x] ROLLING DEBRIS: rocks touch down into a ROLL — downhill pull vs
      friction, so gentle ground stops them after a tumble, steep slopes keep
      them going, and a cliff lip drops them back into free fall (chains
      naturally down terraced cave walls); settle only on near-flat ground
- [x] DEEP CONTENT BOOST: extra seam belt (7-10 silver + 2 meteoric) and 9
      extra mean packs below -20 m — the wide galleries got their garrisons
- [x] FIELD POLISH PASS (gen/deep/reset pipelines): 1-sample walls thicken
      (see-through cracks between rocks sealed for good) and floating
      single-sample rock shards dissolve (no tip-touching polygons)
- [x] MINEABLE SURFACE BOULDERS: 3-4 pickaxe bites by size (chips per bite),
      burst into rubble + 2-4 Rock pickups on the last
- [x] LOADING BLACKOUTS + BED SEQUENCE: black curtain over startup until the
      whole underground (and content) is real; sleeping = lie-down animation →
      blackout while the deep re-carves → get-up animation; ALL input locked
      during curtains and bed animations (no lag ever reaches the eye)
- [x] ANTI-GLITCH CAMERA: near plane 0.02 + full-width head-sphere collider —
      no more pressing the lens through cave walls to peek out of the world
- [x] DEEP GALLERIES: the worm-tunnel depth ramp tripled + a pinch floor —
      the true deeps run as wide round cylinders you could drive a cart through
- [x] RIM WALL REMOVED: the map edge is open flat ground that simply ends
      (caves still taper shut before it; outer shells + bottom stay unmineable)
- [x] HORSE HEARTS: 3 hits to fell any horse, +1 heart per 3 unharmed seconds,
      ♥♥♡ billboard pips over the head (deplete right-to-left, pop on hit,
      fade when calm); bestiary HP reads 3
- [x] METEOR FALLS (random event, ~3-8 min + dev button): burning streak down
      the sky, lands away from the player/permanent caves, carves a REAL
      crater, fuses a ball of 7 meteoric veins at its heart (Terraria's
      meteor, but the ore spawns as a mineable BALL in the middle), rubble +
      quake + "A Star Falls" + compass direction hint
- [x] CREATURE INFIGHTING: melee arcs splash onto other creatures (×0.6);
      creature-on-creature damage sets a MUTUAL grudge — both retarget and
      brawl until death or leash; horses struck by creatures flee without
      losing trust in you
- [~] Random world events + titles — first pass: "The Hollow Depths / The Dusk
      Forest" fade in when entering/leaving the caves; Daybreak/Nightfall sky
      banners now ride the day/night clock (surface only)
- [x] Day/night cycle — DayNight.gd: full Skyrim-pace 20-min game day (72×),
      sun + moon on one wheel, keyframed sky/fog/ambient around the clock
      (17:30 = the original signature dusk), dark frost-blue nights where the
      torch really matters, caves ignore the sky entirely. Starts at 17:00.
      Danger cycles (bolder undead at night) still to come — is_night() is ready

## Step 10 — Leveling & progression [~]
- [x] XP + level-up to cap 99, 3 stat points per level, banked until spent.
      Curve retuned SLOW on request (~24 weak kills for level 2, ~5.2M XP total
      to 99). Orb XP re-trimmed AGAIN: every current mob drops GREEN essence
      (orb_tier 0, 2 XP/orb; yellow→purple saved for real elites, scaling
      slowly at 3/4/5), stronger kinds just drop MORE greens (3/5/7/9 orbs
      by xp_tier) — levels are earned
- [x] Five stats (CON/DEX/STR/WIS/CHA, base 5, cap 99) with diminishing-returns
      formulas driving HP/stamina pools + bar width, stamina costs/regen, move +
      attack speed, damage, damage taken, carry limit, XP gain, gold found
- [x] Progression trees ("grow what you use"): hidden achievement tiers that pay
      escalating points into their linked stat — Death's Door (near-death
      recoveries), Marathoner (distance), Untouchable (i-frame dodges),
      Combo Master (finishers), Perfect Guard (parries), Slayer (kills),
      Essence Drinker (XP orbs); Silver Tongue locked until NPCs.
      Endless: past the authored tiers, thresholds keep scaling per completion
- [x] Tab menu: Inventory | Stats | Progression — Cyberpunk-style stat sheet with
      hover tooltips (live before→after numbers) + achievement page with hidden tiers
- [ ] WIS gates sword tiers / sword arts (comes with steps 4–5)
- [ ] CHA grows through conversation (needs NPCs, step 6)
- [x] Save/persistence — Settings SAVE/LOAD buttons (dev; SaveGame.gd v2,
      migrates v1): full snapshot — player (pos/health/stamina/level/xp/
      stats/progression tiers/bestiary/gold), inventory + Terraria equipment
      + Q-wheel, world hour, ground logs, and the caves as seed + shift count
      + a 30 m density SPHERE around the player (4 m blend rim) so a cave
      camp survives while the rest regenerates to connect. FINAL DESIGN:
      the real game saves ONLY on sleep — that trigger still to wire
- [ ] Long-term scaling pass once higher-tier XP sources exist

## Step 11 — Customization & final art [ ]
- [ ] Skyrim-style character creator
- [ ] Realistic textures + actors replace placeholders

---

## Systems added along the way
- [x] Settings menu (Esc, saved to user://settings.cfg): "Ray-Traced Lighting"
      preset — SDFGI real-time GI + SSIL/SSAO/SSR + volumetric light shafts +
      glow, with flat ambient scaled back so bounce light leads (World.gd
      set_rt_lighting); shadow quality tiers; fullscreen/VSync/sensitivity/FOV.
      All live-applied. (Godot has no hardware RT — SDFGI is its ray-marched GI)
- [x] Ground pickups: coins/XP scatter and fall on death; walk over them and they fly to you
- [x] Dev mob-spawn menu (M) — spawns any mob ~10 ft ahead (confused until hit)
- [x] Inventory (I / Tab): item list, carry-weight limit (overweight = slowed, no sprint),
      armor slots (helmet/chest/arms/pants/shoes) + shield offhand slot
- [x] Offhand items: shield + torch owned from the start; Q cycles owned items only;
      equip raise/lower animation, shield block-raise, torch casts real flickering light
- [x] Shield + torch held TOGETHER (shield straps to the forearm, torch shares the
      fist — Q gains a combined mode; "offhand2" companion slot in the inventory)
- [x] Shield sheathes with the sword: stows across the back (also while the bow has
      both hands), redraws on unsheathe; raising a block auto-draws steel
- [x] THE HUNCH (settings toggle, default on): auto-unsheathe the moment any hostile
      turns agitated at you (edge-triggered, horses excluded), auto-sheathe after
      6.7 quiet seconds
- [x] All menus render 67% bigger (MENU_SCALE, clamped so pages fit the window)
- [x] CLIMBING on Space: grabbable ledge ahead (≤2.65 m) = mantle instead of jump
      (rise-then-haul animation, hands plant, camera dip, stamina cost, works
      mid-air) — the answer to steep voxel-cave terrain; pairs with digging
      footholds via the pickaxe
- [x] Walk-feel + cave polish pass: camera bump absorber (feet bump, view
      glides), voxel grass skin blends flush into the slab at region rims,
      smaller entrance mound with a low dark arch, ~40% of systems roll VAST
      (fatter tunnels, much bigger caverns), and a dev M-menu button that
      TEARS OPEN a new cave region at runtime (slab re-tiled, quake + title —
      first taste of DESIGN.md's "caves open up in the earth")
- [x] SEAMLESS REGION BORDERS: the "giant patch" is gone — region surface is
      perfectly flat + exact slab grass away from the entrance (jitter now
      returns only with depth or near the mouth), and the skin dips 7 cm under
      the slab overhang at the rim so the border never z-fights
- [x] MAP-WIDE UNDERGROUND: one 208 m CaveField under the whole world — the
      voxel grass top replaced the slab entirely (no borders exist anymore,
      dig anywhere), caves run under everything with SPATIAL vastness (slow
      noise swings the underground between tight warrens and grand halls),
      multiple mouths into one shared underground, runtime add_mouth for the
      M-menu button (no ground surgery), content counts scaled up
- [x] DARK SKY BELOW + GOD RAYS AT THE MOUTH: underground the fog owns the sky
      (any glimpse reads gloom); every entrance pours a warm daylight shaft
      down its throat — SpotLight + nested additive beam cones (the bright
      thing underground is the way out)
- [x] INVENTORY 2.0: Diablo/Minecraft layout — equipped paper doll (hands +
      armor + 2 empty accessory berths) with one-click set equip, 9×3 backpack
      slot GRID (stacks; refuses when full; more backpacks later = more rows),
      coin PURSE in 4 denominations (copper/silver/gold/platinum ×100 ladder,
      shown as counts); dev Armory column retired into the G creative menu
- [x] MANUAL PICKUPS: everything except coins/XP is now look+E — ores from
      digging AND veins (first-of-metal auto-forge preserved), mob sword drops
      lie in the dirt as real blades, landed mining rocks gatherable ("Rock"),
      felled trees scatter Sticks around the crown crash
- [x] DIG-ORE: every pickaxe bite of bare rock rolls a depth-scaled ore chance
      (richer + likelier the deeper you go; endgame metals excluded from the
      ground per MATERIALS.md); ore bursts out as a pickup, first-of-metal
      auto-forge still applies
- [x] ONE-CLICK SET EQUIP: any complete 5-piece material kit in the pack shows
      an "Equip X set" button in the Inventory
- [x] CREATIVE MENU (G, dev): every item in the game — sword / armor set / ore
      for all 10 metals + shield/torch/pickaxe/arrows/bedroll/wood/junk
- [x] FALL DAMAGE: safe to ~6 m, scaling damage past it, hard landings (≥17.5
      m/s) fold into the knockdown, lethal falls kill; mid-air mantle zeroes it
- [x] WAR AXE (weapon 4): heavy one-hand cleaver, ×1.35 damage, two alternating
      authored swing animations (overhead chop / left-to-right cleave), impact-
      timed arc hits; first non-sword melee weapon (step-4 styles groundwork)
- [x] TREE FELLING with the axe: per-bite wood chips + trunk shiver, size-based
      chop counts, timber fall animation (eased tip, canopy crash chips +
      proximity shake, bounce, sink away), drops 2-4 Wood — first wood economy
      hook for the step-7 building set
- [x] SUNKEN ENTRANCE + DEFERRED DEEPS: entrance redone as an open descending
      ramp cut that dives under a low rock cap (only the cap top breaks the
      surface; surface cuts hard-limited to the mouth zone — no more back-side
      holes); ALL systems roomy underneath (vast baseline 0.6, 40% roll 1.0);
      the deep rows (below −8 m) are placeholder rock until the player
      approaches — then carved + meshed on worker threads, polled without
      blocking, and only then do crystals/veins/dwellers spawn. Player digs
      into placeholder rock survive the real carve (minf preserve)
- [x] Grassy entrance hills over the cave mouths; branchier cave networks with loops
      and a guaranteed 3-way junction
- [x] Armory (dev) column on the I inventory page — grab any material sword;
      swords are inventory items on a "Main Hand" slot, click to wield
- [x] Bestiary (Tab page 4): all mobs listed, each row ??? until first kill;
      per-material weakness cells stay ??? until you land that metal on that
      creature (learn-by-doing "prove the matchup" discovery, with log toasts).
- [x] Material ARMOR SETS: all 10 metals as 5-piece kits (helmet/chestplate/
      bracers/greaves/boots) via the Armory's Armor button; each worn piece
      shaves 2/3/4/5% damage by tier (set: 10→25%, cap 40%); piece weight rides
      the metal (mithril kit light, adamant kit brutal); worn pieces TINT the
      visible body + viewmodel forearm. Helmets stats-only (no head mesh)
- [x] Drop & reclaim: Q over an inventory row tosses ONE of that item out in
      front of you (DroppedItem.gd — arcs, lands, lies there; NO magnet);
      look at it + E picks it back up ("[E] Pick up" prompt). Last-sword drop
      blocked (main hand never empty); equipment indices remap on removal
      Kills now counted centrally in Enemy._die → Player.on_mob_slain, so bow
      and pickaxe kills feed the Slayer tree too (they didn't before)
- [x] Mining: Iron Pickaxe in the starting pack (weapon 3), chop animation with
      impact-timed bite; OreVein.gd rocks (4 hits, seam flash + chips + shake)
      burst into ore pickups; Cave.gd seeds silver veins through rooms and
      meteoric in the deepest; first ore of a metal auto-forges that sword

### Batch of 2026-07-19 → 07-29
- [x] SAVE/LOAD in Settings (dev buttons) — see step 10 for the full snapshot;
      cave saves keep a 30 m sphere around you, the rest regenerates to connect
- [x] GRASS ×2 / ×2.5 DENSITY + CUT-GRASS LITTER: severed blades pendulum down
      like leaves and STAY (litter pool; later gusts may nudge a few)
- [x] TREES FALL LIKE THE FOREST: chopping carves a real WEDGE NOTCH into the
      trunk (spawned-cube notch retired) that deepens per swing until the tree
      breaks at it; on GROUND IMPACT the crown sheds every leaf in the crown's
      footprint (most stay, ~22% blow 2-15 m downwind, Ghost-of-Tsushima
      style) and the trunk splits into round(height) LOGS
- [x] CARRY LOGS: logs lie where they roll; look+E hoists up to 4 over the
      shoulder; drawing an item, getting hit, jumping, climbing, crouching or
      going prone spills them; logs persist through save/load
- [x] STICKS are real forked stick sprites (cubes retired); sword starts
      SHEATHED on load-in
- [x] ENEMY ROUT: badly hurt enemies BREAK and hobble away slowly; flying/
      climbing types scramble up and off
- [x] CRYSTALS MINEABLE: light crystals break apart shard by shard, the glow
      dimming as they go; DIG-ORE now pays EVERYWHERE but rarer overall
- [x] COMMITTED STRIKE: Ctrl-dash DURING a swing = lunging power hit for a big
      stamina bite; two new progression trees — THE COMMITTED STEP (DEX, land
      them) and NOTHING LEFT TO LOSE (CON, land them below 30% health)
- [x] HORSES SHUN CAVES (16 m soft / 8 m hard avoidance) and HORSES CLIMB —
      including under saddle: ride into a steep face and the horse scrambles
      up it (approach press + grace window + haul-over)
- [x] LEFT-HAND TOGGLE (settings): mirrors the hands, the visible body and
      every animation
- [x] METEOR 2.0: a burning point hangs visible in the sky day or night
      (dimmer by day), ~23 s slow descent, then the crash — same crater + ore
- [x] ELEMENTAL BLADE + ARMOR FX — see step 5 (orange fire w/ burn DoT, white,
      amber, purple void flow; pixel-particle effects)
- [x] ORE PICKUPS LOOK LIKE ORE: mini-veins (~0.6 m), and veins BREAK into
      2-3 near-vein-size chunks instead of pebbles
- [x] ACTION CAMERA: lens + hands (head + body in 3rd person) ride the
      animations — sword swings CARRY the view across and RAMP swing over
      swing, the axe rolls in from the side, landed hits punch the lens
- [x] OLD RUCKSACK: a visible pack on the back (bedroll straps onto it;
      bedroll hard-capped at one) + RUMMAGE — opening the inventory drops the
      eyes and reaches the hands into the pack
- [x] AXE SWINGS FROM THE SIDE; B = drop button; HEALTH POTION (+40);
      Q ITEM WHEEL (8 slots: tap Q in the inventory to add, hold Q to place);
      the creeping sprint-disable bug fixed
- [x] TERRARIA EQUIPMENT: every paper-doll slot is a real CONTAINER — items
      move OUT of the grid INTO the slot and back; the Old Rucksack is a BACK
      accessory slot that grants the extra rows (no pack worn = 9 pockets);
      saves restore the doll exactly as left; first load spawns born-dressed
- [x] THE CAVE LAB (M menu, New Cave 1-4): four rival generators as walk-in
      massifs — Polished Worms / Halls & Passages / The Riverbed / The
      Cathedral — dressed entrances + real spawns; the bake-off the
      Cathedral WON (step 9)

---

## Notes for automated build runs
- Keep the game runnable after every change; prefer code-built nodes over fragile
  scene wiring where practical.
- Match the design doc (`docs/DESIGN.md`). When a decision is ambiguous, leave a
  `TODO(design):` comment rather than guessing a core direction.
- Update this file's checkboxes as work completes.
