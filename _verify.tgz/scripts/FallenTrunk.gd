class_name FallenTrunk
extends RigidBody3D

## ===========================================================================
## The trunk on its way down, and where it lies afterwards.
## docs/TREES_v2_SPEC.md §8b — and the part Lemon asked for: it can land on you.
##
## Physics, not animation: it tips the way you were standing when you took the
## last bite, it crashes, and whatever is underneath finds out. If you are not
## wearing enough armour it PINS you — you are on the ground until it rolls off
## or someone drags you out. Ten seconds pinned and the game offers you F to
## reload, because being stuck under a log forever is a bug, not a story.
##
## Once it is lying still, chopping it BUCKS it: one log per bite.
## ===========================================================================

const CRASH_SPEED := 2.5           ## impact speed that counts as "it landed"
const CRUSH_DAMAGE := 46.0         ## a mature trunk across the back
const CRUSH_RADIUS := 2.2
const PIN_ARMOR_TIER := 3          ## wear this or better and it only knocks you down
const PIN_SECONDS := 7.0           ## how long until it rolls off you
const BUCK_LENGTH := 2.0           ## metres of trunk per log (spec §8b)
const MIN_FALL_TIME := 1.6         ## it may not "settle" before it has fallen
const TOPPLE_PUSH := 2.4           ## impulse at the top, per kg of trunk

const BARK := {
	"maple": Color(0.145, 0.120, 0.105), "birch": Color(0.66, 0.66, 0.62),
	"oak": Color(0.125, 0.105, 0.092), "pine": Color(0.135, 0.105, 0.088),
	"fir": Color(0.115, 0.100, 0.092),
}

var species := "maple"
var trunk_len := 8.0
var trunk_r := 0.3
var logs_left := 3
var settled := false

var _crashed := false
var _age := 0.0
var _pinned_player: Node3D = null
var _pin_t := 0.0
var _mesh: MeshInstance3D


static func make(at: Vector3, fall_dir: Vector3, length: float, radius: float,
		species_id: String, logs: int) -> FallenTrunk:
	var t := FallenTrunk.new()
	t.species = species_id
	t.trunk_len = length
	t.trunk_r = radius
	t.logs_left = maxi(logs, 1)
	t.position = at
	t.set_meta("fall_dir", fall_dir)
	return t


func _ready() -> void:
	add_to_group("fallen_trunks")
	add_to_group("choppable")
	mass = clampf(trunk_len * trunk_r * 120.0, 60.0, 900.0)
	contact_monitor = true
	max_contacts_reported = 4
	continuous_cd = true

	var cyl := CylinderMesh.new()
	cyl.top_radius = trunk_r * 0.72
	cyl.bottom_radius = trunk_r
	cyl.height = trunk_len
	cyl.radial_segments = 10
	_mesh = MeshInstance3D.new()
	_mesh.mesh = cyl
	## Wear the species' real bark, not a flat colour — a felled trunk you can
	## walk up to is exactly where the parallax pays off. CylinderMesh UVs run
	## 0..1, and the bark shader wants metres, so tiling converts.
	_mesh.material_override = _bark_material(trunk_r, trunk_len)
	## the log lies along its own local Y; start it standing, physics does the rest
	add_child(_mesh)

	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = trunk_r
	shape.height = trunk_len
	cs.shape = shape
	add_child(cs)

	## Stand it up where the tree stood: the body's origin is the MIDDLE of the
	## cylinder, so it has to sit half a trunk above the stump or the log spawns
	## buried to the waist.
	position.y += trunk_len * 0.5

	## Then shove the TOP of it over. A real trunk hinges on its stump, and a
	## push applied high does that far more convincingly than spinning the whole
	## body about its centre.
	var dir: Vector3 = get_meta("fall_dir", Vector3.FORWARD)
	dir.y = 0.0
	if dir.length_squared() < 0.01:
		dir = Vector3.FORWARD
	dir = dir.normalized()
	call_deferred("_start_topple", dir)

	body_entered.connect(_on_body_entered)


func _start_topple(dir: Vector3) -> void:
	## Deferred so the body is in the physics world before it gets hit.
	apply_impulse(dir * mass * TOPPLE_PUSH, Vector3.UP * trunk_len * 0.42)
	angular_velocity += dir.cross(Vector3.UP).normalized() * -0.7


func _physics_process(delta: float) -> void:
	## THE BUG THAT KEPT TREES STANDING: this used to freeze the body the instant
	## it was slow — which on frame one, before gravity had touched it, was
	## immediately. The trunk froze bolt upright and never fell. It has to be
	## given time to actually go over first.
	_age += delta
	if _age < MIN_FALL_TIME:
		return
	if not settled and linear_velocity.length() < 0.3 and angular_velocity.length() < 0.35:
		settled = true
		freeze = true     ## stop simulating a log that has finished falling

	if _pinned_player != null:
		_pin_t += delta
		if _pin_t >= PIN_SECONDS:
			_release_pin()


func _on_body_entered(body: Node) -> void:
	if _crashed:
		return
	_crashed = true

	for p in get_tree().get_nodes_in_group("player"):
		if p.has_method("tree_crash_shake"):
			p.tree_crash_shake(global_position)

	## Anything caught under the crown takes it.
	for node in get_tree().get_nodes_in_group("player") + get_tree().get_nodes_in_group("enemies"):
		var n3 := node as Node3D
		if n3 == null or not is_instance_valid(n3):
			continue
		if n3.global_position.distance_to(global_position) > CRUSH_RADIUS + trunk_len * 0.4:
			continue
		if n3.has_method("take_damage"):
			n3.take_damage(CRUSH_DAMAGE, global_position, true)
		_try_pin(n3)


func _try_pin(who: Node3D) -> void:
	## Enough armour and you are merely knocked flat. Not enough, and the trunk
	## has you until it rolls.
	if _pinned_player != null or not who.is_in_group("player"):
		return
	var tier := 0
	if who.has_method("armor_tier"):
		tier = int(who.call("armor_tier"))
	if tier >= PIN_ARMOR_TIER:
		return                      ## plate holds; the knockdown from take_damage is enough
	if who.has_method("pin_under"):
		who.call("pin_under", self, PIN_SECONDS)
		_pinned_player = who
		_pin_t = 0.0


func _release_pin() -> void:
	if _pinned_player != null and is_instance_valid(_pinned_player) \
			and _pinned_player.has_method("release_pin"):
		_pinned_player.call("release_pin")
	_pinned_player = null
	_pin_t = 0.0
	## it rolls off — a shove away from whoever was under it
	freeze = false
	settled = false
	apply_central_impulse(Vector3(randf_range(-1.0, 1.0), 0.4, randf_range(-1.0, 1.0)) * mass * 0.05)


func free_pinned() -> void:
	## Someone else rolled it off you. (Co-op hook — see spec §8b.)
	_release_pin()


## ---------------------------------------------------------------- bucking ---

func chop_hit(_toward_chopper: Vector3, _aim := Vector3.INF) -> bool:
	## One bite of the axe on a downed trunk cuts one log free.
	if not settled:
		return false
	logs_left -= 1
	_spawn_log()
	trunk_len = maxf(trunk_len - BUCK_LENGTH, 0.0)
	if logs_left <= 0 or trunk_len < BUCK_LENGTH * 0.5:
		_scatter_last()
		queue_free()
		return true
	_resize()
	return false


func _resize() -> void:
	var cyl := _mesh.mesh as CylinderMesh
	if cyl != null:
		cyl.height = trunk_len
	for c in get_children():
		var cs := c as CollisionShape3D
		if cs != null and cs.shape is CylinderShape3D:
			(cs.shape as CylinderShape3D).height = trunk_len


func _spawn_log() -> void:
	var world := get_parent()
	var cl := CarryLog.make(BUCK_LENGTH * 0.9, trunk_r, BARK.get(species, Color(0.2, 0.16, 0.13)))
	world.add_child(cl)
	cl.global_position = global_position + Vector3.UP * 0.2 \
		+ (global_transform.basis * Vector3.UP) * trunk_len * 0.4
	cl.toss(Vector3(randf_range(-1.2, 1.2), randf_range(0.4, 1.1), randf_range(-1.2, 1.2)))


func _scatter_last() -> void:
	var world := get_parent()
	for _i in range(randi_range(1, 3)):
		var s := DroppedItem.make({"name": "Stick", "weight": 0.3, "count": 1, "slot": ""})
		world.add_child(s)
		s.global_position = global_position + Vector3(randf_range(-0.8, 0.8), 0.3,
			randf_range(-0.8, 0.8))
		s.velocity = Vector3(randf_range(-1.5, 1.5), randf_range(1.0, 2.0), randf_range(-1.5, 1.5))


func _bark_material(r: float, along: float) -> Material:
	## One shared ShaderMaterial per species would tile wrongly on differently
	## sized logs, so this takes a duplicate and sets the tiling for THIS piece.
	var base: Material = TreeV2.materials_for(species)[0]
	var m: ShaderMaterial = (base as ShaderMaterial).duplicate()
	m.set_shader_parameter("tiling", Vector2(maxf(TAU * r * 1.6, 0.5), maxf(along * 1.6, 0.5)))
	m.set_shader_parameter("sway", 0.0)      ## it is on the ground; it does not sway
	return m
