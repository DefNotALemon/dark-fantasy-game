class_name TreeV2
extends StaticBody3D

## ===========================================================================
## A standing tree.  docs/TREES_v2_SPEC.md §5, §8
##
## Replaces ChopTree.gd. The shape comes from a GLB built by tools/treegen2.py,
## which exports each tree as an empty root with a `Trunk` child and one
## `Branch_NN` child per order-1 limb. Those names ARE the gameplay model:
## every branch is its own object, so the axe can take them off one at a time.
##
## The rule that makes a big tree feel like a job of work:
##   THE TRUNK REFUSES THE AXE UNTIL EVERY BRANCH IS OFF.
## Limb it, then fell it, then buck the fallen trunk into logs.
## ===========================================================================

const GLB_PATH := "res://assets/trees/glb/%s_%d_%s.glb"
const STAGE_NAMES: Array[String] = ["sapling", "young", "mature", "ancient", "withered"]
const ALL_SPECIES: Array[String] = ["maple", "birch", "oak", "pine", "fir"]

## Stage -> how many 2 m logs the trunk bucks into (spec §4)
const LOG_YIELD: Array[int] = [0, 1, 3, 5, 2]
## Stage -> axe bites the bare trunk takes before it goes over
const TRUNK_CHOPS: Array[int] = [1, 2, 4, 6, 3]
## Stage -> trunk radius in metres, for the collider and the fallen log
const TRUNK_R: Array[float] = [0.03, 0.10, 0.30, 0.46, 0.30]
const TRUNK_H: Array[float] = [1.1, 3.6, 8.2, 11.0, 8.0]

const REACH := 3.4                  ## how far the axe can find a limb
const NOTCH_Y := 1.05               ## the height a chopper naturally swings at

@export var species := "maple"
@export var stage := 2

var tree_seed := 0
var felled := false
var trunk_chops := 0
var scale_class := 1.0              ## NORMAL 1.0 / ELDER 1.7 / GREAT 3.5-4.5 (spec §4)

var _model: Node3D
var _trunk: MeshInstance3D
var _branches: Array = []           ## of TreeBranch
var _col: CollisionShape3D


static func make(rng: RandomNumberGenerator, species_id := "", stage_i := -1) -> TreeV2:
	var t := TreeV2.new()
	t.species = species_id if species_id != "" else ALL_SPECIES[rng.randi() % ALL_SPECIES.size()]
	## Stage weights: the forest is mostly grown, with a scatter of young and old.
	if stage_i >= 0:
		t.stage = stage_i
	else:
		var r := rng.randf()
		t.stage = 1 if r < 0.18 else (2 if r < 0.74 else (3 if r < 0.92 else 4))
	t.tree_seed = rng.randi()
	## ELDER roll — the tree you notice (spec §4). GREAT trees are hand-placed.
	if t.stage >= 2 and rng.randf() < 0.04:
		t.scale_class = 1.7
	return t


func _ready() -> void:
	add_to_group("trees")
	add_to_group("choppable")
	trunk_chops = TRUNK_CHOPS[stage]
	_build()


func _build() -> void:
	var path := GLB_PATH % [species, stage, STAGE_NAMES[stage]]
	var packed := load(path)
	if packed == null:
		push_warning("TreeV2: missing model %s" % path)
		return
	_model = packed.instantiate()
	_model.scale = Vector3.ONE * scale_class
	add_child(_model)

	## Walk the exported hierarchy. treegen2.py guarantees these names.
	var parts: Node = _model
	if _model.get_child_count() == 1 and _model.get_child(0).get_child_count() > 0:
		parts = _model.get_child(0)     ## Godot wraps the glTF scene in a root
	for child in parts.get_children():
		var mi := child as MeshInstance3D
		if mi == null:
			continue
		if mi.name.begins_with("Trunk"):
			_trunk = mi
		elif mi.name.begins_with("Branch"):
			var b := TreeBranch.new()
			b.setup(mi, self)
			add_child(b)
			_branches.append(b)

	## Cap the limbing job: the thickest MAX_LIMBS gate the trunk, everything
	## thinner is scenery that comes down with it.
	var gating: Array = []
	for b in _branches:
		if (b as TreeBranch).blocks_trunk:
			gating.append(b)
	gating.sort_custom(func(a, c): return (a as TreeBranch).radius() > (c as TreeBranch).radius())
	for i in range(gating.size()):
		(gating[i] as TreeBranch).blocks_trunk = i < TreeBranch.MAX_LIMBS

	## Trunk collision: one capsule, sized from the stage, scaled with the class.
	_col = CollisionShape3D.new()
	var cyl := CylinderShape3D.new()
	cyl.radius = maxf(TRUNK_R[stage] * scale_class, 0.06)
	cyl.height = TRUNK_H[stage] * scale_class
	_col.shape = cyl
	_col.position.y = cyl.height * 0.5
	add_child(_col)


## --------------------------------------------------------------- gameplay ---

func branches_left() -> int:
	## Only the limbs that gate the trunk are counted — see TreeBranch.blocks_trunk.
	var n := 0
	for b in _branches:
		var tb := b as TreeBranch
		if is_instance_valid(tb) and not tb.gone and tb.blocks_trunk:
			n += 1
	return n


func nearest_branch(from: Vector3, aim: Vector3) -> TreeBranch:
	## Prefer whatever the swing is actually pointed at; fall back to whatever
	## is closest, so a wild swing still bites something.
	var best: TreeBranch = null
	var best_d := INF
	var target := aim if aim != Vector3.INF else from
	for b in _branches:
		var tb := b as TreeBranch
		if not is_instance_valid(tb) or tb.gone or not tb.blocks_trunk:
			continue
		var d := tb.hit_point().distance_to(target)
		if d < best_d:
			best_d = d
			best = b
	return best if best_d < REACH * scale_class else null


func chop_hit(toward_chopper: Vector3, aim := Vector3.INF) -> bool:
	## One bite of the axe. Returns TRUE only on the swing that fells the tree,
	## which is what Player listens for to shout "Timber!".
	if felled:
		return false

	## --- limbing comes first, always ---
	if branches_left() > 0:
		var b := nearest_branch(global_position, aim)
		if b == null:
			for cand in _branches:
				var tc := cand as TreeBranch
				if is_instance_valid(tc) and not tc.gone and tc.blocks_trunk:
					b = tc
					break
		if b != null and not b.gone:
			b.take_hit(1)
		return false

	## --- bare trunk: now it will accept the axe ---
	trunk_chops -= 1
	_shiver(toward_chopper)
	if trunk_chops > 0:
		return false
	_fell(-toward_chopper)
	return true


func trunk_blocked() -> bool:
	return branches_left() > 0


func _shiver(world_toward: Vector3) -> void:
	if _model == null:
		return
	var tw := create_tween()
	var away := -world_toward.normalized() * 0.05
	tw.tween_property(_model, "position", away, 0.05)
	tw.tween_property(_model, "position", Vector3.ZERO, 0.16)


func _fell(dir: Vector3) -> void:
	## The trunk becomes a physics object and goes over the way you were
	## standing. It is heavy, it is fast, and it does not care what is under it.
	felled = true
	remove_from_group("trees")
	remove_from_group("choppable")

	var world := get_parent()
	var trunk := FallenTrunk.make(
		global_position + Vector3.UP * (TRUNK_R[stage] * scale_class + 0.15),
		dir.normalized(),
		TRUNK_H[stage] * scale_class,
		TRUNK_R[stage] * scale_class,
		species,
		LOG_YIELD[stage])
	world.add_child(trunk)

	var stump := TreeStump.make(global_position, TRUNK_R[stage] * scale_class, species)
	world.add_child(stump)

	## Tell the player's camera it happened, wherever they are.
	for p in get_tree().get_nodes_in_group("player"):
		if p.has_method("tree_crash_shake"):
			p.tree_crash_shake(global_position)

	queue_free()


func leaf_material() -> Material:
	## Handed to TreeBranch so a break-off leaf burst is the right species and
	## the right season without any extra bookkeeping.
	if _trunk != null and _trunk.mesh != null and _trunk.mesh.get_surface_count() > 1:
		return _trunk.mesh.surface_get_material(1)
	for b in _branches:
		var tb := b as TreeBranch
		if tb != null and tb.mesh != null and tb.mesh.mesh != null \
				and tb.mesh.mesh.get_surface_count() > 1:
			return tb.mesh.mesh.surface_get_material(1)
	return null


## ------------------------------------------------------------------ save ---

func save_dict() -> Dictionary:
	return {
		"kind": "tree_v2",
		"species": species,
		"stage": stage,
		"seed": tree_seed,
		"scale": scale_class,
		"pos": [global_position.x, global_position.y, global_position.z],
		"rot": rotation.y,
		"chops": trunk_chops,
		"branches": _branch_state(),
	}


func _branch_state() -> Array:
	var out: Array = []
	for b in _branches:
		out.append(0 if (is_instance_valid(b) and not b.gone) else 1)
	return out


func restore(d: Dictionary) -> void:
	trunk_chops = int(d.get("chops", TRUNK_CHOPS[stage]))
	var st: Array = d.get("branches", [])
	for i in range(mini(st.size(), _branches.size())):
		if int(st[i]) == 1:
			(_branches[i] as TreeBranch).remove_silently()
