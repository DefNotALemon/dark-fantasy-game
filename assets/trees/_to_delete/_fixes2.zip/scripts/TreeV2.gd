class_name TreeV2
extends StaticBody3D

## ===========================================================================
## A standing tree.  docs/TREES_v2_SPEC.md §5, §8
##
## Replaces ChopTree.gd. The shape comes from a GLB built by tools/treegen2.py,
## which exports each tree as an empty root with a `Trunk` child and one
## `Branch_NN` child per order-1 limb. Those names ARE the gameplay model:
## every branch is its own object, so the axe can take them off one at a time.
##
## The rule that makes a big tree feel like a job of work:
##   THE TRUNK REFUSES THE AXE UNTIL EVERY BRANCH IS OFF.
## Limb it, then fell it, then buck the fallen trunk into logs.
## ===========================================================================

const GLB_PATH := "res://assets/trees/glb/%s_%d_%s.glb"
const STAGE_NAMES: Array[String] = ["sapling", "young", "mature", "ancient", "withered"]
const ALL_SPECIES: Array[String] = ["maple", "birch", "oak", "pine", "fir"]

## Stage -> how many 2 m logs the trunk bucks into (spec §4)
const LOG_YIELD: Array[int] = [0, 1, 3, 5, 2]
## Stage -> axe bites the bare trunk takes before it goes over
## Bites the bare trunk takes. Ancient is 8, not 6, because a tall tree often
## has NO reachable limbs left — white pines self-prune their lower branches, so
## an ancient one is a pure trunk job and the trunk has to carry the weight.
const TRUNK_CHOPS: Array[int] = [1, 2, 4, 8, 4]
## Stage -> trunk radius in metres, for the collider and the fallen log
const TRUNK_R: Array[float] = [0.03, 0.10, 0.30, 0.46, 0.30]
const TRUNK_H: Array[float] = [1.1, 3.6, 8.2, 11.0, 8.0]

const REACH := 3.4                  ## how far the axe can find a limb
const NOTCH_Y := 1.05               ## the height a chopper naturally swings at

## --- materials -------------------------------------------------------------
## The GLBs ship with NO textures on purpose (one shared atlas beats 25 embedded
## copies), so the glTF materials are placeholders and must never be used: they
## are flat grey with a transmission extension Godot can't render, which is what
## made the leaves glitch and the trees go magenta. Everything gets our own
## ShaderMaterial here instead, built once per species and shared by every tree.
const FOLIAGE_SHADER := "res://shaders/foliage.gdshader"
const BARK_SHADER := "res://shaders/bark.gdshader"
const LEAF_ATLAS := "res://assets/trees/leaves/%s_leaf_atlas.png"
const LEAF_NORMAL := "res://assets/trees/leaves/%s_leaf_normal.png"
const BARK_TEX := "res://assets/trees/bark/%s_bark_%s.png"

## spring / summer / autumn / winter, straight out of tools/leafgen.py
const SEASON_RAMPS := {
	"maple": [Color(0.44, 0.56, 0.26), Color(0.24, 0.36, 0.18), Color(0.86, 0.34, 0.09), Color(0.40, 0.22, 0.14)],
	"birch": [Color(0.56, 0.66, 0.31), Color(0.31, 0.43, 0.21), Color(0.87, 0.63, 0.17), Color(0.44, 0.34, 0.18)],
	"oak":   [Color(0.36, 0.46, 0.23), Color(0.19, 0.29, 0.15), Color(0.56, 0.27, 0.12), Color(0.34, 0.22, 0.13)],
	"pine":  [Color(0.20, 0.33, 0.22), Color(0.16, 0.28, 0.20), Color(0.16, 0.27, 0.19), Color(0.21, 0.33, 0.34)],
	"fir":   [Color(0.17, 0.28, 0.21), Color(0.13, 0.24, 0.19), Color(0.13, 0.23, 0.18), Color(0.19, 0.30, 0.33)],
}
## Oak keeps a quarter of its dead leaves all winter (spec §3).
const MARCESCENCE := {"maple": 0.0, "birch": 0.0, "oak": 0.25, "pine": 0.0, "fir": 0.0}
const EVERGREEN := {"pine": true, "fir": true}

static var _mat_cache := {}

@export var species := "maple"
@export var stage := 2

var tree_seed := 0
var felled := false
var trunk_chops := 0
var scale_class := 1.0              ## NORMAL 1.0 / ELDER 1.7 / GREAT 3.5-4.5 (spec §4)

## What the last swing did, for the HUD: "limb", "limb_off", "trunk", "felled".
var last_result := ""

var _model: Node3D
var _trunk: MeshInstance3D
var _branches: Array = []           ## of TreeBranch
var _col: CollisionShape3D


static func make(rng: RandomNumberGenerator, species_id := "", stage_i := -1) -> TreeV2:
	var t := TreeV2.new()
	t.species = species_id if species_id != "" else ALL_SPECIES[rng.randi() % ALL_SPECIES.size()]
	## Stage weights: the forest is mostly grown, with a scatter of young and old.
	if stage_i >= 0:
		t.stage = stage_i
	else:
		var r := rng.randf()
		t.stage = 1 if r < 0.18 else (2 if r < 0.74 else (3 if r < 0.92 else 4))
	t.tree_seed = rng.randi()
	## ELDER roll — the tree you notice (spec §4). GREAT trees are hand-placed.
	if t.stage >= 2 and rng.randf() < 0.04:
		t.scale_class = 1.7
	return t


func _ready() -> void:
	add_to_group("trees")
	add_to_group("choppable")
	trunk_chops = TRUNK_CHOPS[stage]
	_build()


func _build() -> void:
	var path := GLB_PATH % [species, stage, STAGE_NAMES[stage]]
	var packed := load(path)
	if packed == null:
		push_warning("TreeV2: missing model %s" % path)
		return
	_model = packed.instantiate()
	_model.scale = Vector3.ONE * scale_class
	add_child(_model)

	var mats := materials_for(species)

	## Walk the exported hierarchy. treegen2.py guarantees these names.
	var parts: Node = _model
	if _model.get_child_count() == 1 and _model.get_child(0).get_child_count() > 0:
		parts = _model.get_child(0)     ## Godot wraps the glTF scene in a root
	for child in parts.get_children():
		var mi := child as MeshInstance3D
		if mi == null:
			continue
		_apply_materials(mi, mats)
		if mi.name.begins_with("Trunk"):
			_trunk = mi
		elif mi.name.begins_with("Branch"):
			var b := TreeBranch.new()
			b.setup(mi, self)
			add_child(b)
			_branches.append(b)

	## Cap the limbing job: the thickest MAX_LIMBS gate the trunk, everything
	## thinner is scenery that comes down with it.
	var gating: Array = []
	for b in _branches:
		if (b as TreeBranch).blocks_trunk:
			gating.append(b)
	## Lowest first, not thickest first: a woodsman limbs from the bottom up,
	## and the limb you just cut should be the one in front of your face.
	gating.sort_custom(func(a, c): return (a as TreeBranch).base_height() < (c as TreeBranch).base_height())
	for i in range(gating.size()):
		(gating[i] as TreeBranch).blocks_trunk = i < TreeBranch.MAX_LIMBS

	## Trunk collision: one capsule, sized from the stage, scaled with the class.
	_col = CollisionShape3D.new()
	var cyl := CylinderShape3D.new()
	cyl.radius = maxf(TRUNK_R[stage] * scale_class, 0.06)
	cyl.height = TRUNK_H[stage] * scale_class
	_col.shape = cyl
	_col.position.y = cyl.height * 0.5
	add_child(_col)


## -------------------------------------------------------------- materials ---

static func materials_for(species_id: String) -> Array:
	## [bark, leaf] — built once per species and shared by every tree of it.
	if _mat_cache.has(species_id):
		return _mat_cache[species_id]

	var bark := ShaderMaterial.new()
	bark.shader = load(BARK_SHADER)
	bark.set_shader_parameter("bark_albedo", load(BARK_TEX % [species_id, "albedo"]))
	bark.set_shader_parameter("bark_normal", load(BARK_TEX % [species_id, "normal"]))
	bark.set_shader_parameter("bark_rough", load(BARK_TEX % [species_id, "rough"]))
	bark.set_shader_parameter("bark_height", load(BARK_TEX % [species_id, "height"]))
	## UVs are baked in METRES (see treegen2._part_mesh), so tiling is
	## "texture repeats per metre" — same texel density on every trunk.
	bark.set_shader_parameter("tiling", Vector2(1.6, 1.6))

	var leaf := ShaderMaterial.new()
	leaf.shader = load(FOLIAGE_SHADER)
	leaf.set_shader_parameter("leaf_atlas", load(LEAF_ATLAS % species_id))
	leaf.set_shader_parameter("leaf_normal", load(LEAF_NORMAL % species_id))
	var ramp: Array = SEASON_RAMPS.get(species_id, SEASON_RAMPS["maple"])
	leaf.set_shader_parameter("col_spring", ramp[0])
	leaf.set_shader_parameter("col_summer", ramp[1])
	leaf.set_shader_parameter("col_autumn", ramp[2])
	leaf.set_shader_parameter("col_winter", ramp[3])
	leaf.set_shader_parameter("deciduous", not EVERGREEN.has(species_id))
	leaf.set_shader_parameter("marcescence", float(MARCESCENCE.get(species_id, 0.0)))

	_mat_cache[species_id] = [bark, leaf]
	return _mat_cache[species_id]


func _apply_materials(mi: MeshInstance3D, mats: Array) -> void:
	## Match by the glTF material NAME, not by surface index: a trunk with no
	## leaves on it has only one surface, so indices don't line up.
	if mi.mesh == null:
		return
	for i in range(mi.mesh.get_surface_count()):
		var src: Material = mi.mesh.surface_get_material(i)
		var is_leaf := src != null and str(src.resource_name).findn("leaf") >= 0
		mi.set_surface_override_material(i, mats[1] if is_leaf else mats[0])


## --------------------------------------------------------------- gameplay ---

func branches_left() -> int:
	## Only the limbs that gate the trunk are counted — see TreeBranch.blocks_trunk.
	var n := 0
	for b in _branches:
		var tb := b as TreeBranch
		if is_instance_valid(tb) and not tb.gone and tb.blocks_trunk:
			n += 1
	return n


func nearest_branch(from: Vector3, aim: Vector3) -> TreeBranch:
	## Prefer whatever the swing is actually pointed at; fall back to whatever
	## is closest, so a wild swing still bites something.
	var best: TreeBranch = null
	var best_d := INF
	var target := aim if aim != Vector3.INF else from
	for b in _branches:
		var tb := b as TreeBranch
		if not is_instance_valid(tb) or tb.gone or not tb.blocks_trunk:
			continue
		var d := tb.hit_point().distance_to(target)
		if d < best_d:
			best_d = d
			best = b
	return best if best_d < REACH * scale_class else null


func chop_hit(toward_chopper: Vector3, aim := Vector3.INF) -> bool:
	## One bite of the axe. Returns TRUE only on the swing that fells the tree,
	## which is what Player listens for to shout "Timber!".
	if felled:
		return false

	## --- limbing comes first, always ---
	if branches_left() > 0:
		var b := nearest_branch(global_position, aim)
		if b == null:
			for cand in _branches:
				var tc := cand as TreeBranch
				if is_instance_valid(tc) and not tc.gone and tc.blocks_trunk:
					b = tc
					break
		if b != null and not b.gone:
			last_result = "limb_off" if b.take_hit(1) else "limb"
		else:
			last_result = "limb"
		return false

	## --- bare trunk: now it will accept the axe ---
	trunk_chops -= 1
	_shiver(toward_chopper)
	if trunk_chops > 0:
		last_result = "trunk"
		return false
	last_result = "felled"
	_fell(-toward_chopper)
	return true


func trunk_blocked() -> bool:
	return branches_left() > 0


func _shiver(world_toward: Vector3) -> void:
	if _model == null:
		return
	var tw := create_tween()
	var away := -world_toward.normalized() * 0.05
	tw.tween_property(_model, "position", away, 0.05)
	tw.tween_property(_model, "position", Vector3.ZERO, 0.16)


func _fell(dir: Vector3) -> void:
	## The trunk becomes a physics object and goes over the way you were
	## standing. It is heavy, it is fast, and it does not care what is under it.
	felled = true
	remove_from_group("trees")
	remove_from_group("choppable")

	var world := get_parent()
	var trunk := FallenTrunk.make(
		global_position + Vector3.UP * (TRUNK_R[stage] * scale_class + 0.15),
		dir.normalized(),
		TRUNK_H[stage] * scale_class,
		TRUNK_R[stage] * scale_class,
		species,
		LOG_YIELD[stage])
	world.add_child(trunk)

	var stump := TreeStump.make(global_position, TRUNK_R[stage] * scale_class, species)
	world.add_child(stump)

	## Tell the player's camera it happened, wherever they are.
	for p in get_tree().get_nodes_in_group("player"):
		if p.has_method("tree_crash_shake"):
			p.tree_crash_shake(global_position)

	queue_free()


func leaf_material() -> Material:
	## Handed to TreeBranch so a break-off leaf burst is the right species and
	## the right season without any extra bookkeeping.
	if _trunk != null and _trunk.mesh != null and _trunk.mesh.get_surface_count() > 1:
		return _trunk.mesh.surface_get_material(1)
	for b in _branches:
		var tb := b as TreeBranch
		if tb != null and tb.mesh != null and tb.mesh.mesh != null \
				and tb.mesh.mesh.get_surface_count() > 1:
			return tb.mesh.mesh.surface_get_material(1)
	return null


## ------------------------------------------------------------------ save ---

func save_dict() -> Dictionary:
	return {
		"kind": "tree_v2",
		"species": species,
		"stage": stage,
		"seed": tree_seed,
		"scale": scale_class,
		"pos": [global_position.x, global_position.y, global_position.z],
		"rot": rotation.y,
		"chops": trunk_chops,
		"branches": _branch_state(),
	}


func _branch_state() -> Array:
	var out: Array = []
	for b in _branches:
		out.append(0 if (is_instance_valid(b) and not b.gone) else 1)
	return out


static func from_dict(d: Dictionary) -> TreeV2:
	var t := TreeV2.new()
	t.species = str(d.get("species", "maple"))
	t.stage = int(d.get("stage", 2))
	t.tree_seed = int(d.get("seed", 0))
	t.scale_class = float(d.get("scale", 1.0))
	var p: Array = d.get("pos", [0, 0, 0])
	t.position = Vector3(float(p[0]), float(p[1]), float(p[2]))
	t.rotation.y = float(d.get("rot", 0.0))
	return t


func restore(d: Dictionary) -> void:
	trunk_chops = int(d.get("chops", TRUNK_CHOPS[stage]))
	var st: Array = d.get("branches", [])
	for i in range(mini(st.size(), _branches.size())):
		if int(st[i]) == 1:
			(_branches[i] as TreeBranch).remove_silently()
