extends Enemy
class_name DarkKnight
## An armored undead champion — disciplined, dangerous, a real duel. Its own
## specials: "bash" (shield slam that breaks your guard) and "darkcombo" (a fast
## three-hit sword string, blockable but punishing). Does not bull-rush.

var rig: Node3D
var arm: Node3D    ## shoulder pivot (upper arm)
var hand: Node3D   ## elbow/wrist pivot — the longsword hangs off this


func _init() -> void:
	display_name = "Dark Knight"
	max_health = 165.0       ## armored champion — soaks a lot of hits
	wander_speed = 1.2
	chase_speed = 4.2
	attack_range = 2.1
	attack_damage = 18.0
	attack_cooldown = 1.0
	aggro_radius = 13.0
	leash_radius = 28.0
	xp_tier = 3
	## Armored plate over a cursed champion: steel's armor bonus and curse
	## penalty STACK (×1.35 × ×0.8 ≈ ×1.08); silver/voidsteel shine here.
	families = ["cursed", "armored"]
	## Whatever is inside that plate does not know how to retreat.
	nerve = 0.0
	rout_speed = 0.5
	duelist = true
	duel_range = 6.0
	duel_hold_min = 0.5
	duel_hold_max = 1.1
	strong_from_melee = true
	strong_min_range = 0.0
	strong_max_range = 5.0
	telegraph_color = Color(0.70, 0.30, 1.0)
	climb_speed = 2.4   ## armor and all — the cursed don't tire on a wall
	## Gait: measured, disciplined strides (the buckler arm stays planted).
	gait_rate = 0.9
	stride_deg = 26.0
	waddle_deg = 1.2


func _choose_strong(dist: float) -> void:
	if dist <= attack_range + 0.3 and randf() < 0.5:
		strong_mode = "bash"      ## shield slam, guard-break, in place
		strong_damage = 16.0
		strong_speed = 3.0
		strong_windup_time = 0.40
		strong_duration = 0.30
		strong_cooldown = 4.0
		strong_hit_range = 2.2
		strong_breaks_guard = true
		strong_multi_hits = 1
	else:
		strong_mode = "darkcombo" ## three fast sword strikes, blockable
		strong_damage = 12.0
		strong_speed = 2.5
		strong_windup_time = 0.35
		strong_duration = 0.85
		strong_cooldown = 5.0
		strong_hit_range = 2.3
		strong_breaks_guard = false
		strong_multi_hits = 3
		strong_hit_interval = 0.24


## The carry: arm hanging, elbow angling the longsword down and slightly back
## so the point rides just off the ground. A swordsman at rest — not a windmill.
## (Was -40 — the longsword stuck out behind him like a rudder; -14 is the
## disciplined low carry the comment always described.)
const CARRY_ARM := Vector3(-6.0, 4.0, 7.0)
const CARRY_HAND := Vector3(-14.0, 0.0, 4.0)


func _animate(delta: float) -> void:
	if arm == null:
		return
	if strong_windup > 0.0:
		var p := 1.0 - strong_windup / strong_windup_time
		if strong_mode == "bash":
			## Positive yaw draws the LEFT (shield) shoulder back to wind up.
			rig.rotation_degrees = rig.rotation_degrees.lerp(Vector3(0, 22.0 * p, 0), delta * 16.0)   ## wind shield back
			_lerp_carry(delta * 8.0)
		else:
			## Lifts from the carry into a high chamber — announcing the string.
			arm.rotation_degrees = arm.rotation_degrees.lerp(Vector3(lerpf(CARRY_ARM.x, -40.0, p), lerpf(CARRY_ARM.y, 14.0, p), CARRY_ARM.z), delta * 16.0)
			hand.rotation_degrees = hand.rotation_degrees.lerp(Vector3(lerpf(CARRY_HAND.x, -96.0, p), 0, 0), delta * 16.0)
		return
	if strong_active:
		var p := 1.0 - strong_time / strong_duration
		if strong_mode == "bash":
			## The shield SLAMS across the FRONT — accelerating, not gliding.
			## (Was wound the wrong way: the "slam" rotated the shield shoulder
			## backwards, away from you, at the moment the hit landed.)
			var c := minf(p * 2.2, 1.0)
			rig.rotation_degrees = Vector3(0, lerpf(22.0, -30.0, c * c), 0)
			_lerp_carry(delta * 8.0)
		else:
			## Three formal cuts on ALTERNATING diagonals — each whips down
			## decisively and re-chambers with total control. Swordsmanship.
			var k := int(minf(p * 3.0, 2.99))
			var q := fmod(p * 3.0, 1.0)
			var ysign := 1.0 if k % 2 == 0 else -1.0
			var sh: float
			var wr: float
			if q < 0.5:
				var u := q / 0.5
				sh = lerpf(-40.0, 36.0, u * u)
				wr = lerpf(-96.0, 22.0, u * u)
			else:
				var u := (q - 0.5) / 0.5
				var e := u * u * (3.0 - 2.0 * u)
				sh = lerpf(36.0, -40.0, e)
				wr = lerpf(22.0, -96.0, e)
			arm.rotation_degrees = Vector3(sh, ysign * 20.0, 6.0)
			hand.rotation_degrees = Vector3(wr, 0, 0)
			rig.rotation_degrees = Vector3(2.0, ysign * -6.0, 0)  ## squared, upright
		return
	if melee_anim > 0.0:
		## One clean, decisive cut: raised from the carry into a shoulder chamber,
		## driven through the line, recovered without a wasted degree. Dominance.
		var p := 1.0 - melee_anim / MELEE_ANIM_TIME
		arm.rotation_degrees = Vector3(
			_cut_arc(p, CARRY_ARM.x, -44.0, 42.0),
			_cut_arc(p, CARRY_ARM.y, 16.0, -10.0),
			_cut_arc(p, CARRY_ARM.z, 8.0, -2.0))
		hand.rotation_degrees = Vector3(
			_cut_arc(p, CARRY_HAND.x, -102.0, 24.0), 0, _cut_arc(p, CARRY_HAND.z, 5.0, -2.0))
		rig.rotation_degrees = Vector3(_swing_arc(p, -3.0, 5.0), 0, 0)
		return
	rig.rotation_degrees = rig.rotation_degrees.lerp(Vector3.ZERO, delta * 8.0)
	## Between attacks the longsword is HELD low at his side, barely disturbed
	## by the walk. Elegance is stillness.
	_lerp_carry(delta * 8.0, sin(walk_t) * 4.0 * _loco_amount)


func _lerp_carry(k: float, sway := 0.0) -> void:
	arm.rotation_degrees = arm.rotation_degrees.lerp(CARRY_ARM + Vector3(sway, 0, 0), k)
	hand.rotation_degrees = hand.rotation_degrees.lerp(CARRY_HAND + Vector3(sway * 0.4, 0, 0), k)


func _build_body() -> void:
	_add_collision(Vector3(0.7, 1.8, 0.6), Vector3(0, 0.95, 0))

	var plate := Color(0.16, 0.16, 0.20)
	var plate_hi := Color(0.24, 0.24, 0.30)
	var steel := Color(0.55, 0.57, 0.62)
	var cloth := Color(0.30, 0.10, 0.34)
	base_body_color = plate

	rig = Node3D.new()
	add_child(rig)
	loco_root = rig  ## footfall bob while it walks

	## Cuirass + tattered tabard.
	var body := _box_in(rig, Vector3(0.56, 0.72, 0.36), plate, Vector3(0, 1.15, 0))
	body_mat = body.material_override as StandardMaterial3D
	_box_in(rig, Vector3(0.30, 0.55, 0.05), cloth, Vector3(0, 1.02, -0.20))
	_box_in(rig, Vector3(0.66, 0.18, 0.42), plate_hi, Vector3(0, 1.48, 0))       ## pauldrons
	## Great helm with a horizontal visor slit.
	_box_in(rig, Vector3(0.30, 0.34, 0.30), plate_hi, Vector3(0, 1.72, -0.02))
	_box_in(rig, Vector3(0.24, 0.04, 0.03), Color(0.02, 0.02, 0.03), Vector3(0, 1.72, -0.18))
	_box_in(rig, Vector3(0.06, 0.20, 0.06), steel, Vector3(0, 1.96, 0), Vector3(6, 0, 0))   ## crest spike
	## Left arm holding a small shield / buckler.
	_box_in(rig, Vector3(0.15, 0.55, 0.15), plate, Vector3(-0.38, 1.14, 0))
	_box_in(rig, Vector3(0.06, 0.44, 0.44), plate_hi, Vector3(-0.46, 1.05, -0.12))          ## buckler
	_box_in(rig, Vector3(0.10, 0.10, 0.06), steel, Vector3(-0.49, 1.05, -0.34))             ## boss
	## Right arm: SHOULDER pivot for the upper arm, elbow pivot (`hand`) for the
	## gauntlet and longsword. Two joints, so the blade rests down at his side
	## like a real swordsman's and chambers over the shoulder to cut.
	arm = Node3D.new()
	rig.add_child(arm)
	arm.position = Vector3(0.38, 1.42, 0)
	_box_in(arm, Vector3(0.15, 0.55, 0.15), plate, Vector3(0, -0.26, 0))
	hand = Node3D.new()
	arm.add_child(hand)
	hand.position = Vector3(0, -0.52, 0)
	_box_in(hand, Vector3(0.17, 0.17, 0.17), plate_hi, Vector3(0, -0.06, 0))                      ## gauntlet fist
	_box_in(hand, Vector3(0.06, 0.06, 0.06), steel, Vector3(0, 0.04, 0))                          ## pommel
	_box_in(hand, Vector3(0.26, 0.05, 0.06), plate_hi, Vector3(0, -0.16, 0))                      ## crossguard
	_box_in(hand, Vector3(0.055, 0.95, 0.045), steel, Vector3(0, -0.65, 0), Vector3.ZERO, true)   ## blade
	arm.rotation_degrees = CARRY_ARM
	hand.rotation_degrees = CARRY_HAND
	## Legs / greaves: hip pivots that actually stride.
	for lx: float in [-0.15, 0.15]:
		var leg := Node3D.new()
		rig.add_child(leg)
		leg.position = Vector3(lx, 0.72, 0)
		_box_in(leg, Vector3(0.20, 0.68, 0.22), plate, Vector3(0, -0.34, 0))
		walk_legs.append(leg)

	_add_eye(Vector3(-0.07, 1.72, -0.17), Vector3(0.05, 0.03, 0.03), rig)
	_add_eye(Vector3(0.07, 1.72, -0.17), Vector3(0.05, 0.03, 0.03), rig)
