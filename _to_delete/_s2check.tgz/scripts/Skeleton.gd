extends Enemy
class_name Skeleton
## Slow, tanky undead swordsman. Hostile on sight.
## Specials: "smash" — plants its feet, raises the blade high (pale glow), then
## a crushing overhead blow that BREAKS a raised guard. "sweep" — winds the arm
## out wide and cuts across; faster, blockable.

var rig: Node3D    ## whole visible body (leans with attacks)
var arm: Node3D    ## right shoulder pivot (upper arm)
var hand: Node3D   ## elbow/wrist pivot — the rusty sword hangs off this


func _init() -> void:
	display_name = "Skeleton"
	max_health = 60.0
	wander_speed = 1.0
	chase_speed = 3.4
	attack_range = 1.9
	attack_damage = 10.0
	attack_cooldown = 1.4
	aggro_radius = 12.0
	leash_radius = 26.0
	xp_tier = 2
	families = ["undead"]
	## Bone has no nerve to break. It fights until it is scattered.
	nerve = 0.0
	rout_speed = 0.5
	duelist = true
	strong_throws = true         ## its heavy blows knock you aside
	strong_throw_power = 6.0     ## a stumble, not a launch
	## Both specials are close-range: trigger just outside melee (or from melee).
	strong_min_range = 0.0
	strong_max_range = 2.6
	strong_from_melee = true
	telegraph_color = Color(0.85, 0.88, 1.0)
	climb_speed = 2.5   ## bone fingers find every crack — steady, tireless
	## Gait: a stiff, dead-legged shamble.
	gait_rate = 0.8
	stride_deg = 24.0
	waddle_deg = 1.6


func _choose_strong(_dist: float) -> void:
	if randf() < 0.6:
		strong_mode = "smash"  ## guard-crushing overhead blow, done in place
		strong_damage = 26.0
		strong_speed = 0.0
		strong_windup_time = 0.75
		strong_duration = 0.30
		strong_cooldown = 5.0
		strong_hit_range = 2.4
		strong_breaks_guard = true
		strong_multi_hits = 1
	else:
		strong_mode = "sweep"  ## a lunging wide cut — shoves you aside and steps past
		strong_damage = 14.0
		strong_speed = 7.0
		strong_windup_time = 0.45
		strong_duration = 0.35
		strong_cooldown = 3.5
		strong_hit_range = 2.7
		strong_breaks_guard = false
		strong_multi_hits = 1


## The carry: the arm hangs, the wrist angles the rusty blade down and A TOUCH
## back so its point drags just above the dirt. It lifts from here into every
## cut. (Was -32 — the blade trailed way out behind the shins; -12 keeps it
## hanging at the side.)
const CARRY_ARM := Vector3(-4.0, 0.0, 7.0)
const CARRY_HAND := Vector3(-12.0, 0.0, 5.0)


func _animate(delta: float) -> void:
	if arm == null:
		return
	if strong_windup > 0.0:
		var p := 1.0 - strong_windup / strong_windup_time
		if strong_mode == "smash":
			## Raise the blade high above the skull, leaning back.
			arm.rotation_degrees = arm.rotation_degrees.lerp(Vector3(lerpf(CARRY_ARM.x, -52.0, p), 0, CARRY_ARM.z * (1.0 - p)), delta * 12.0)
			hand.rotation_degrees = hand.rotation_degrees.lerp(Vector3(lerpf(CARRY_HAND.x, -112.0, p), 0, 0), delta * 12.0)
			rig.rotation_degrees = rig.rotation_degrees.lerp(Vector3(-9.0 * p, 0, 0), delta * 12.0)
		else:
			## Wind the arm out wide, point levelled across the body.
			arm.rotation_degrees = arm.rotation_degrees.lerp(Vector3(lerpf(CARRY_ARM.x, -18.0, p), 68.0 * p, CARRY_ARM.z), delta * 12.0)
			hand.rotation_degrees = hand.rotation_degrees.lerp(Vector3(lerpf(CARRY_HAND.x, 96.0, p), 0, 0), delta * 12.0)
			rig.rotation_degrees = rig.rotation_degrees.lerp(Vector3(0, 28.0 * p, 0), delta * 12.0)
		return
	if strong_active:
		var p := 1.0 - strong_time / strong_duration
		if strong_mode == "smash":
			## The blow ACCELERATES all the way down — gravity plus intent.
			var c := p * p
			arm.rotation_degrees = Vector3(lerpf(-52.0, 44.0, c), 0, 0)
			hand.rotation_degrees = Vector3(lerpf(-112.0, 28.0, c), 0, 0)
			rig.rotation_degrees = Vector3(lerpf(-9.0, 15.0, c), 0, 0)
		else:
			## The sweep whips out of the wind and eases off the follow-through.
			var c := p * p * (3.0 - 2.0 * p)
			arm.rotation_degrees = Vector3(-18.0, lerpf(68.0, -80.0, c), CARRY_ARM.z)
			hand.rotation_degrees = Vector3(96.0, 0, 0)
			rig.rotation_degrees = Vector3(0, lerpf(28.0, -30.0, c), 0)
		return
	if melee_anim > 0.0:
		## Lift out of the carry, chamber at the shoulder, cut through, recover.
		var p := 1.0 - melee_anim / MELEE_ANIM_TIME
		arm.rotation_degrees = Vector3(
			_cut_arc(p, CARRY_ARM.x, -40.0, 40.0), 0, _cut_arc(p, CARRY_ARM.z, 9.0, -3.0))
		hand.rotation_degrees = Vector3(
			_cut_arc(p, CARRY_HAND.x, -95.0, 22.0), 0, _cut_arc(p, CARRY_HAND.z, 6.0, -2.0))
		rig.rotation_degrees = Vector3(_swing_arc(p, -6.0, 8.0), 0, 0)
		return
	## Ease back to the carry — the sword arm sways with the walk until the
	## next attack pose takes it over.
	var sway := sin(walk_t) * 9.0 * _loco_amount
	arm.rotation_degrees = arm.rotation_degrees.lerp(CARRY_ARM + Vector3(sway, 0, 0), delta * 8.0)
	hand.rotation_degrees = hand.rotation_degrees.lerp(CARRY_HAND + Vector3(sway * 0.4, 0, 0), delta * 8.0)
	rig.rotation_degrees = rig.rotation_degrees.lerp(Vector3.ZERO, delta * 8.0)


func _build_body() -> void:
	_add_collision(Vector3(0.55, 1.75, 0.45), Vector3(0, 0.9, 0))

	rig = Node3D.new()
	add_child(rig)
	loco_root = rig  ## footfall bob while it walks

	var bone := Color(0.86, 0.83, 0.74)
	var dark_bone := Color(0.62, 0.58, 0.50)
	var steel := Color(0.55, 0.58, 0.62)
	base_body_color = bone

	## Ribcage (the "body" that flashes/telegraphs).
	var ribs := _box_in(rig, Vector3(0.42, 0.44, 0.26), bone, Vector3(0, 1.18, 0))
	body_mat = ribs.material_override as StandardMaterial3D
	## Rib gaps (dark inset stripes).
	_box_in(rig, Vector3(0.44, 0.04, 0.22), dark_bone, Vector3(0, 1.10, 0))
	_box_in(rig, Vector3(0.44, 0.04, 0.22), dark_bone, Vector3(0, 1.24, 0))
	## Spine + pelvis.
	_box_in(rig, Vector3(0.10, 0.24, 0.10), dark_bone, Vector3(0, 0.84, 0))
	_box_in(rig, Vector3(0.34, 0.16, 0.22), bone, Vector3(0, 0.68, 0))
	## Skull + jaw.
	_box_in(rig, Vector3(0.26, 0.26, 0.26), bone, Vector3(0, 1.58, 0))
	_box_in(rig, Vector3(0.20, 0.08, 0.20), dark_bone, Vector3(0, 1.42, -0.02))
	## Left arm hangs loose — on a shoulder pivot so it swings with the stride.
	var larm := Node3D.new()
	rig.add_child(larm)
	larm.position = Vector3(-0.28, 1.36, 0)
	_box_in(larm, Vector3(0.09, 0.52, 0.09), dark_bone, Vector3(0, -0.26, 0))
	walk_arms.append(larm)
	## Right arm: SHOULDER pivot for the upper arm, elbow pivot (`hand`) for the
	## sword. The blade runs along the forearm's line, so it hangs at the side.
	arm = Node3D.new()
	rig.add_child(arm)
	arm.position = Vector3(0.28, 1.36, 0)
	_box_in(arm, Vector3(0.09, 0.52, 0.09), dark_bone, Vector3(0, -0.26, 0))
	hand = Node3D.new()
	arm.add_child(hand)
	hand.position = Vector3(0, -0.50, 0)
	## Rusty sword gripped in the bony fist — blade down, point trailing.
	_box_in(hand, Vector3(0.18, 0.04, 0.05), dark_bone, Vector3(0, -0.06, 0))                       ## crossguard
	_box_in(hand, Vector3(0.045, 0.75, 0.035), steel, Vector3(0, -0.44, 0), Vector3.ZERO, true)     ## blade
	arm.rotation_degrees = CARRY_ARM
	hand.rotation_degrees = CARRY_HAND
	## Legs: hip pivots that actually stride.
	for lx: float in [-0.12, 0.12]:
		var leg := Node3D.new()
		rig.add_child(leg)
		leg.position = Vector3(lx, 0.60, 0)
		_box_in(leg, Vector3(0.10, 0.60, 0.10), dark_bone, Vector3(0, -0.30, 0))
		walk_legs.append(leg)

	## Glowing eye sockets.
	_add_eye(Vector3(-0.07, 1.60, -0.12), Vector3(0.06, 0.06, 0.05), rig)
	_add_eye(Vector3(0.07, 1.60, -0.12), Vector3(0.06, 0.06, 0.05), rig)
