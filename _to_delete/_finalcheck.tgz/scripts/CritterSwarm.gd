class_name CritterSwarm
extends Node3D

## ===========================================================================
## SWARMS — the things there are too many of to think.  docs/WILDLIFE.md §1
##
## Bats out of the mill gables at dusk, fireflies over a June meadow, a
## blackfly cloud that follows you across a bog, monarchs drifting one way
## south all September. None of these has AI, a health bar, or a collision
## shape. They are ONE MultiMeshInstance3D each, steered by noise, and they
## carry more atmosphere per millisecond than anything else in the feature.
##
## The rule that keeps them cheap: no per-member nodes, no physics, no
## allocation after build. The whole swarm is a transform array rewritten in
## place each frame.
##
## Blackflies are the exception that earns its keep — they are the only swarm
## that touches the player, and being chased off a bog by insects in late
## spring is a real Maine experience and a real reason to plan travel around
## the season.
## ===========================================================================

const HARASS_DPS := 0.9          ## the nagging tick, not a threat
const HARASS_RADIUS := 2.6
const SMOKE_RADIUS := 7.0        ## a fire or a smudge keeps them off you

var species := "firefly"
var count := 20
var radius := 9.0                ## how far members range from the swarm centre
var height := 3.0
var speed := 1.4
var follows_player := false
var glows := false

var _mm: MultiMeshInstance3D
var _phase: PackedFloat32Array = PackedFloat32Array()
var _seed: PackedFloat32Array = PackedFloat32Array()
var _t := 0.0
var _harass_t := 0.0
var _home := Vector3.ZERO


static func make(key: String, at: Vector3) -> CritterSwarm:
	var s := CritterSwarm.new()
	s.species = key
	var _p := CritterDex.get_profile(key)
	s.count = int(CritterDex.flag(key, "swarm", 12))
	s.glows = bool(CritterDex.flag(key, "glows", false))
	s.follows_player = bool(CritterDex.flag(key, "harasses", false)) \
		or bool(CritterDex.flag(key, "lightseek", false))
	match key:
		"bat":
			s.radius = 22.0
			s.height = 7.0
			s.speed = 7.5
		"firefly":
			s.radius = 14.0
			s.height = 1.9
			s.speed = 0.8
		"blackfly":
			s.radius = 2.4
			s.height = 1.7
			s.speed = 2.4
		"dragonfly":
			s.radius = 10.0
			s.height = 1.4
			s.speed = 4.5
		"monarch":
			s.radius = 16.0
			s.height = 2.6
			s.speed = 1.6
		"luna_moth":
			s.radius = 4.0
			s.height = 2.0
			s.speed = 1.1
		"tidepool":
			s.radius = 3.0
			s.height = 0.10
			s.speed = 0.35
		_:
			s.radius = 8.0
	s.position = at
	return s


func _ready() -> void:
	add_to_group("critter_swarms")
	add_to_group("wildlife")
	_home = global_position
	_build()


func _build() -> void:
	var p := CritterDex.get_profile(species)
	var L := float(p.get("len", 0.05))
	var col: Color = p.get("col", Color.WHITE)

	var mesh := BoxMesh.new()
	## Fliers read as a smear, not a body — a wide flat box at this size is a
	## wingbeat. A crab is a crab.
	if species == "tidepool":
		mesh.size = Vector3(L * 1.6, L * 0.7, L * 1.4)
	else:
		mesh.size = Vector3(maxf(L * 3.0, 0.03), maxf(L * 0.7, 0.008), maxf(L * 1.4, 0.02))

	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = 1.0
	mat.vertex_color_use_as_albedo = false
	if glows:
		## Fireflies are the whole reason the gloom is worth having.
		mat.emission_enabled = true
		mat.emission = col
		mat.emission_energy_multiplier = 3.2
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if species == "blackfly" or species == "bat":
		mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL

	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = mesh
	mm.instance_count = count

	_mm = MultiMeshInstance3D.new()
	_mm.multimesh = mm
	_mm.material_override = mat
	_mm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_mm)

	_phase.resize(count)
	_seed.resize(count)
	for i in range(count):
		_phase[i] = randf() * TAU
		_seed[i] = randf() * 10.0
		mm.set_instance_color(i, Color.WHITE)
	_write(0.0)


func _process(delta: float) -> void:
	_t += delta
	## Off-screen swarms do nothing. There is no state to keep warm.
	var pl := get_tree().get_first_node_in_group("player") as Node3D
	if pl != null:
		var d := global_position.distance_to(pl.global_position)
		if d > 90.0:
			return
		if follows_player and d < 40.0:
			## Blackflies find you. That is their entire personality.
			var want := pl.global_position + Vector3(0, 0.6, 0)
			global_position = global_position.lerp(want, clampf(delta * 0.55, 0.0, 1.0))
		if bool(CritterDex.flag(species, "harasses", false)) and d < HARASS_RADIUS:
			_harass(pl, delta)
	_write(delta)


func _harass(pl: Node3D, delta: float) -> void:
	## Smoke, water and speed all beat them. Standing still in a bog does not.
	for f in get_tree().get_nodes_in_group("campfires"):
		if (f as Node3D).global_position.distance_to(pl.global_position) < SMOKE_RADIUS:
			return
	if pl.has_method("apply_bug_bites"):
		pl.call("apply_bug_bites", HARASS_DPS * delta)
		return
	_harass_t += delta
	if _harass_t >= 1.0:
		_harass_t = 0.0
		if pl.has_method("take_damage"):
			pl.take_damage(HARASS_DPS, global_position, false, Vector3.INF, null)


func _write(_delta: float) -> void:
	## The whole swarm, rewritten in place. Three sines and a seed per member
	## gives every one of them its own wandering path without a single
	## allocation or a single branch.
	var mm := _mm.multimesh
	var flat := species == "tidepool"
	for i in range(count):
		var s := _seed[i]
		var ph := _phase[i]
		var t := _t * speed
		var x := sin(t * 0.31 + ph) * radius * (0.35 + 0.65 * sin(s))
		var z := cos(t * 0.27 + ph * 1.7) * radius * (0.35 + 0.65 * cos(s * 1.3))
		var y := height * (0.5 + 0.5 * sin(t * 0.53 + s * 2.1))
		if flat:
			## Tidepool life scuttles; it does not fly.
			y = 0.02
			x = sin(t * 0.5 + ph) * radius
			z = cos(t * 0.41 + s) * radius
		elif species == "monarch":
			## The one-way southward drift — a calendar you can watch.
			z += fposmod(t * 0.5 + s * 3.0, radius * 2.0) - radius
			y = height * (0.4 + 0.35 * sin(t * 1.7 + ph))
		elif species == "bat":
			## Bats strafe: fast, erratic, and mostly in a plane.
			x += sin(t * 2.3 + s) * 3.4
			z += cos(t * 1.9 + s * 2.0) * 3.4
			y = height * (0.7 + 0.3 * sin(t * 3.1 + ph))
		var pos := Vector3(x, y, z)

		## Face travel. Cheap approximation: the derivative of the sines.
		var vx := cos(t * 0.31 + ph)
		var vz := -sin(t * 0.27 + ph * 1.7)
		var yaw := atan2(vx, vz)
		var b := Basis(Vector3.UP, yaw)
		if not flat:
			b = b.rotated(b.x, sin(t * 9.0 + ph) * 0.5)   ## wingbeat roll
		mm.set_instance_transform(i, Transform3D(b, pos))

		if glows:
			## Fireflies do not glow continuously — they pulse, out of step,
			## and the dark between the flashes is the effect.
			var blink := pow(maxf(sin(t * 1.7 + ph * 3.1), 0.0), 8.0)
			mm.set_instance_color(i, Color(1, 1, 1, 1) * blink)


func set_visible_for(hour: float, phase: float) -> void:
	## The director keeps swarms honest about when they exist: no fireflies in
	## February, no blackflies in the snow, no bats at noon.
	visible = CritterDex.is_awake(species, hour, phase)
	set_process(visible)
