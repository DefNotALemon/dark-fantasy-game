#!/usr/bin/env python3
"""
Wire the wildlife system into World.gd.

    python3 tools/patch_wildlife.py            # patch
    python3 tools/patch_wildlife.py --check    # report only, change nothing
    python3 tools/patch_wildlife.py --revert   # put the .bak back

Re-runnable: every edit is guarded by a marker, so running it twice is a
no-op rather than a mess. Same contract as tools/patch_repo.py — the original
is kept as World.gd.bak_wildlife before anything is written.

Six edits, all in scripts/World.gd:

  1. member vars for the three wildlife nodes + the GAME DAY COUNTER
  2. _ready()      -> build them after the enemies spawn
  3. _process()    -> advance the day, publish the season, push the clock
  4. save_state()  -> write the live wildlife
  5. apply_state() -> put it back
  6. _build_wildlife() appended

Edit 3 is worth reading twice. The shipped World calls Wind.publish_season(0.0)
exactly once, at startup, and nothing ever advances it — so `season_phase` is
pinned to early spring forever and the trees-v2 season system (TREES_v2_SPEC
§7) has never actually run in game. There is no day counter anywhere in the
project. This patch adds one, derived from DayNight's hour wrapping past
midnight, which turns the seasons on for the trees as well as the wildlife.
"""

import argparse
import pathlib
import re
import sys

MARK = "## --- wildlife ---"

EDITS = [
    # (name, anchor regex, insertion, "after"|"before"|"replace")
    (
        "member vars",
        r"^var _wind: Wind\n",
        """var _wind: Wind
%s
var _wildlife: WildlifeDirector      ## who is out there, and when
var _telegraph: Telegraph            ## the forest's alarm bus
var _critter_audio: CritterAudio     ## calls, and the ambience bed
## THE GAME DAY COUNTER. Nothing in the project had one: DayNight owns the
## hour and wraps it at midnight, but nobody was counting the wraps, so
## Wind.publish_season() was called once with 0.0 at startup and the world has
## been stuck in early spring ever since — for the trees too. Counting days
## here turns the whole season system on. One season = 24 days (Wind).
var _game_day := 0.0
var _prev_hour := DayNight.START_HOUR
""" % MARK,
        "replace",
    ),
    (
        "_ready hook",
        r"^\t_spawn_enemies\(\)\n",
        "\t_spawn_enemies()\n\t_build_wildlife()  %s\n" % MARK,
        "replace",
    ),
    (
        "_process clock",
        r"^\t## Random events: now and then, the sky lets something go\.\n",
        """\t%s  Advance the calendar and hand it to everything that reads it.
\tif _daynight != null:
\t\tvar h: float = _daynight.hour
\t\tif h < _prev_hour - 12.0:
\t\t\t_game_day += 1.0        ## the clock wrapped past midnight
\t\t_prev_hour = h
\t\tWind.publish_season(_game_day)
\t\tif _wildlife != null:
\t\t\t_wildlife.set_clock(h, _game_day)

\t## Random events: now and then, the sky lets something go.
""" % MARK,
        "replace",
    ),
    (
        "save_state",
        r'^\t\t"trees": trees, "logs": logs, "dropped": dropped, "beds": beds,\n',
        """\t\t"trees": trees, "logs": logs, "dropped": dropped, "beds": beds,
\t\t"day": _game_day,  %s
""" % MARK,
        "replace",
    ),
    (
        "apply_state",
        r'^\tif _daynight:\n\t\t_daynight\.hour = float\(d\.get\("hour", 17\.0\)\)\n',
        """\tif _daynight:
\t\t_daynight.hour = float(d.get("hour", 17.0))
\t\t_prev_hour = _daynight.hour
\t_game_day = float(d.get("day", 0.0))  %s
\tWind.publish_season(_game_day)
\tif _wildlife != null:
\t\t_wildlife.apply_state(d.get("wildlife", {}) as Dictionary)
""" % MARK,
        "replace",
    ),
]

SAVE_HOOK = (
    r'^\tif _region != null:\n\t\tout\["cave"\] = _region\.save_state\(\)\n',
    """\tif _wildlife != null:
\t\tout["wildlife"] = _wildlife.save_state()  %s
\tif _region != null:
\t\tout["cave"] = _region.save_state()
""" % MARK,
)

BUILDER = '''

## ============================== Wildlife ===================================
%s
## Three nodes, in this order, because each finds the last one:
##   Telegraph      the alarm bus every animal rings and listens to
##   CritterAudio   the calls and the ambience bed (half the feature)
##   WildlifeDirector  who spawns, where, and when
##
## See docs/WILDLIFE.md. Set USE_WILDLIFE = false to turn the whole thing off
## in one line if it ever misbehaves — same escape hatch as USE_TREES_V2.


const USE_WILDLIFE := true


func _build_wildlife() -> void:
	if not USE_WILDLIFE:
		return
	_telegraph = Telegraph.new()
	add_child(_telegraph)
	_critter_audio = CritterAudio.new()
	add_child(_critter_audio)
	_wildlife = WildlifeDirector.new()
	_wildlife.player = _player
	_wildlife.world_radius = WORLD_RADIUS
	add_child(_wildlife)
	_wildlife.set_clock(_daynight.hour if _daynight else 17.0, _game_day)
	## The hand-placed pass: a chickadee flock by the camp, a squirrel in the
	## near timber, and one deer out at the tree line — so the first things a
	## player meets are the one that lands on your hand, the one that tells the
	## forest you are here, and the one that runs.
	_wildlife.seed_world()


func wildlife_census() -> Dictionary:
	## For the debug menu and the test suite.
	return _wildlife.census() if _wildlife != null else {}
''' % MARK


def patch(root: pathlib.Path, check: bool) -> int:
    path = root / "scripts" / "World.gd"
    if not path.exists():
        print("!! not found: %s" % path)
        return 1
    src = path.read_text()
    original = src

    if MARK in src:
        print("== already patched (marker present) — nothing to do")
        return 0

    applied, missed = [], []
    for name, anchor, repl, _mode in EDITS:
        pat = re.compile(anchor, re.MULTILINE)
        if not pat.search(src):
            missed.append(name)
            continue
        src = pat.sub(lambda _m: repl, src, count=1)
        applied.append(name)

    pat = re.compile(SAVE_HOOK[0], re.MULTILINE)
    if pat.search(src):
        src = pat.sub(lambda _m: SAVE_HOOK[1], src, count=1)
        applied.append("save_state wildlife block")
    else:
        missed.append("save_state wildlife block")

    src = src.rstrip("\n") + "\n" + BUILDER

    for name in applied:
        print("   + %s" % name)
    for name in missed:
        print("   !! ANCHOR NOT FOUND: %s  (patch it by hand — see the docstring)" % name)

    if check:
        print("== --check: nothing written")
        return 0 if not missed else 2
    if src == original:
        print("== no changes")
        return 0

    bak = path.with_suffix(".gd.bak_wildlife")
    if not bak.exists():
        bak.write_text(original)
        print("   kept original at %s" % bak.name)
    path.write_text(src)
    print("== patched %s" % path)
    return 0 if not missed else 2


def revert(root: pathlib.Path) -> int:
    path = root / "scripts" / "World.gd"
    bak = path.with_suffix(".gd.bak_wildlife")
    if not bak.exists():
        print("!! no backup at %s" % bak.name)
        return 1
    path.write_text(bak.read_text())
    print("== reverted %s from %s" % (path.name, bak.name))
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="repo root (default: cwd)")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    r = pathlib.Path(a.root).resolve()
    sys.exit(revert(r) if a.revert else patch(r, a.check))
